import { useMemo, useState } from "react";

type IconName =
  | "home"
  | "search"
  | "plus"
  | "sparkle"
  | "users"
  | "book"
  | "grid"
  | "image"
  | "more"
  | "arrow"
  | "wand"
  | "bell"
  | "close"
  | "upload"
  | "check"
  | "heart"
  | "download"
  | "edit"
  | "share"
  | "camera";

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    home: (
      <>
        <path d="M3 10.5 12 3l9 7.5" />
        <path d="M5 9.5V21h14V9.5M9 21v-7h6v7" />
      </>
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    plus: (
      <>
        <path d="M12 5v14M5 12h14" />
      </>
    ),
    sparkle: (
      <>
        <path d="m12 3 1.4 4.1L17.5 8.5l-4.1 1.4L12 14l-1.4-4.1-4.1-1.4 4.1-1.4L12 3Z" />
        <path d="m19 14 .8 2.2L22 17l-2.2.8L19 20l-.8-2.2L16 17l2.2-.8L19 14Z" />
      </>
    ),
    users: (
      <>
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
      </>
    ),
    book: (
      <>
        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z" />
      </>
    ),
    grid: (
      <>
        <rect x="3" y="3" width="7" height="7" rx="1" />
        <rect x="14" y="3" width="7" height="7" rx="1" />
        <rect x="3" y="14" width="7" height="7" rx="1" />
        <rect x="14" y="14" width="7" height="7" rx="1" />
      </>
    ),
    image: (
      <>
        <rect x="3" y="3" width="18" height="18" rx="2" />
        <circle cx="8.5" cy="8.5" r="1.5" />
        <path d="m21 15-5-5L5 21" />
      </>
    ),
    more: (
      <>
        <circle cx="5" cy="12" r="1" fill="currentColor" stroke="none" />
        <circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" />
        <circle cx="19" cy="12" r="1" fill="currentColor" stroke="none" />
      </>
    ),
    arrow: (
      <>
        <path d="M5 12h14M13 6l6 6-6 6" />
      </>
    ),
    wand: (
      <>
        <path d="m15 4 5 5L8 21H3v-5L15 4Z" />
        <path d="m13 6 5 5M5 3v4M3 5h4M19 16v5M16.5 18.5h5" />
      </>
    ),
    bell: (
      <>
        <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" />
      </>
    ),
    close: (
      <>
        <path d="m6 6 12 12M18 6 6 18" />
      </>
    ),
    upload: (
      <>
        <path d="M12 16V4M7 9l5-5 5 5M4 20h16" />
      </>
    ),
    check: (
      <>
        <path d="m5 12 4 4L19 6" />
      </>
    ),
    heart: (
      <>
        <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />
      </>
    ),
    download: (
      <>
        <path d="M12 3v12m-5-5 5 5 5-5M5 21h14" />
      </>
    ),
    edit: (
      <>
        <path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z" />
      </>
    ),
    share: (
      <>
        <circle cx="18" cy="5" r="3" />
        <circle cx="6" cy="12" r="3" />
        <circle cx="18" cy="19" r="3" />
        <path d="m8.6 10.5 6.8-4M8.6 13.5l6.8 4" />
      </>
    ),
    camera: (
      <>
        <path d="M14.5 5 13 3h-2L9.5 5H5a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2Z" />
        <circle cx="12" cy="12.5" r="4" />
        <path d="M18 8h.01" />
      </>
    ),
  };
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  );
}

const photos = {
  beach:
    "https://images.unsplash.com/photo-1553670440-f4fa1dfeabf4?auto=format&fit=crop&w=1200&q=85",
  walk: "https://images.unsplash.com/photo-1725975735073-61ae4e150312?auto=format&fit=crop&w=900&q=85",
  field:
    "https://images.unsplash.com/photo-1615574147300-62cc3e37868f?auto=format&fit=crop&w=900&q=85",
  coast:
    "https://images.unsplash.com/photo-1700908608272-14425ac565e9?auto=format&fit=crop&w=1000&q=85",
  path: "https://images.unsplash.com/photo-1734660264096-c1cc4768454f?auto=format&fit=crop&w=900&q=85",
};

const albums = [
  { title: "Saltwater days", meta: "24 photos · 3 friends", image: photos.beach, color: "#e9a895" },
  { title: "Sunday, slowly", meta: "18 photos · Journal", image: photos.field, color: "#b9c9a5" },
  { title: "Somewhere south", meta: "42 photos · Shared", image: photos.coast, color: "#d5b476" },
];

export default function App() {
  const [active, setActive] = useState("Home");
  const [prompt, setPrompt] = useState("");
  const [creating, setCreating] = useState(false);
  const [notice, setNotice] = useState("");
  const [query, setQuery] = useState("");
  const [showNotifications, setShowNotifications] = useState(false);
  const [modal, setModal] = useState<null | { type: "import" | "create" | "album"; title: string }>(
    null,
  );
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [selectedStyle, setSelectedStyle] = useState("Editorial");
  const [liked, setLiked] = useState<string[]>([]);
  const [menuAlbum, setMenuAlbum] = useState<string | null>(null);

  const showNotice = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 2800);
  };

  const searchResults = useMemo(() => {
    if (!query.trim()) return [];
    const term = query.toLowerCase();
    return albums.filter(
      (album) =>
        album.title.toLowerCase().includes(term) || album.meta.toLowerCase().includes(term),
    );
  }, [query]);

  const generate = () => {
    if (!prompt.trim()) {
      setPrompt("A sun-faded weekend with my favorite people");
      return;
    }
    setCreating(true);
    window.setTimeout(() => {
      setCreating(false);
      setModal({ type: "create", title: prompt });
    }, 1300);
  };

  const navigate = (label: string) => {
    setActive(label);
    setQuery("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const openCreator = (title: string) => {
    setPrompt(title === "Collage" ? "A tactile collage of my favorite recent moments" : title);
    setModal({ type: "create", title });
  };

  const openAlbum = (title: string) => {
    setMenuAlbum(null);
    setModal({ type: "album", title });
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="wordmark">
          memor<span>a</span>
        </div>
        <nav className="side-nav" aria-label="Main navigation">
          {[
            ["Home", "home"],
            ["Library", "image"],
            ["Create", "sparkle"],
            ["Shared", "users"],
            ["Journal", "book"],
          ].map(([label, icon]) => (
            <button
              key={label}
              className={active === label ? "active" : ""}
              onClick={() => navigate(label)}
            >
              <Icon name={icon as IconName} />
              <span>{label}</span>
            </button>
          ))}
        </nav>
        <div className="storage-card">
          <span className="tiny-label">CLOUD SPACE</span>
          <div>
            <strong>8.4 GB</strong>
            <span> of 15 GB</span>
          </div>
          <div className="storage-track">
            <i />
          </div>
          <button onClick={() => showNotice("You have 6.6 GB of space remaining.")}>
            Manage storage
          </button>
        </div>
        <button className="profile" onClick={() => showNotice("Profile settings are ready.")}>
          <span className="avatar">AM</span>
          <span>
            <strong>Alex Morgan</strong>
            <small>Personal studio</small>
          </span>
          <Icon name="more" size={18} />
        </button>
      </aside>

      <main>
        <header className="topbar">
          <button className="mobile-mark" onClick={() => navigate("Home")} aria-label="Memora home">
            memora
          </button>
          <div className="search-wrap">
            <label className="search">
              <Icon name="search" size={18} />
              <input
                placeholder="Search people, places, moments..."
                aria-label="Search memories"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
              />
              {query ? (
                <button
                  className="clear-search"
                  onClick={() => setQuery("")}
                  aria-label="Clear search"
                >
                  <Icon name="close" size={14} />
                </button>
              ) : (
                <kbd>⌘ K</kbd>
              )}
            </label>
            {query && (
              <div className="search-results">
                <span className="tiny-label">MATCHING STORIES</span>
                {searchResults.length ? (
                  searchResults.map((album) => (
                    <button key={album.title} onClick={() => openAlbum(album.title)}>
                      <img src={album.image} alt="" />
                      <span>
                        <strong>{album.title}</strong>
                        <small>{album.meta}</small>
                      </span>
                      <Icon name="arrow" size={16} />
                    </button>
                  ))
                ) : (
                  <p>No stories match “{query}”</p>
                )}
              </div>
            )}
          </div>
          <div className="top-actions">
            <button
              className={`icon-button ${showNotifications ? "selected" : ""}`}
              aria-label="Notifications"
              onClick={() => setShowNotifications(!showNotifications)}
            >
              <Icon name="bell" size={19} />
              <i />
            </button>
            <button
              className="import-button"
              onClick={() => setModal({ type: "import", title: "Bring in new memories" })}
            >
              <Icon name="plus" size={17} /> Import photos
            </button>
          </div>
          {showNotifications && (
            <aside className="notification-panel">
              <div>
                <span className="tiny-label">ACTIVITY</span>
                <button
                  onClick={() => setShowNotifications(false)}
                  aria-label="Close notifications"
                >
                  <Icon name="close" size={17} />
                </button>
              </div>
              <h3>Notifications</h3>
              <button className="activity-item" onClick={() => openAlbum("Saltwater days")}>
                <span className="activity-avatar coral">JL</span>
                <span>
                  <strong>Jamie added 8 photos</strong>
                  <small>to Saltwater days · 12m</small>
                </span>
              </button>
              <button className="activity-item" onClick={() => openAlbum("Somewhere south")}>
                <span className="activity-avatar olive">
                  <Icon name="sparkle" size={15} />
                </span>
                <span>
                  <strong>Your story is ready</strong>
                  <small>Somewhere south · 1h</small>
                </span>
              </button>
              <button
                className="mark-read"
                onClick={() => {
                  setShowNotifications(false);
                  showNotice("All caught up.");
                }}
              >
                <Icon name="check" size={14} /> Mark all as read
              </button>
            </aside>
          )}
        </header>

        <div className="content">
          {active === "Home" ? (
            <>
              <section className="intro">
                <div>
                  <p className="eyebrow">WEDNESDAY, MAY 21</p>
                  <h1>
                    Your memories,
                    <br />
                    <em>beautifully told.</em>
                  </h1>
                </div>
                <p className="intro-copy">
                  Turn a camera roll full of moments into stories worth keeping — thoughtfully
                  organized by you and a little bit of magic.
                </p>
              </section>

              <section className="ai-studio">
                <div className="ai-copy">
                  <span className="ai-badge">
                    <Icon name="sparkle" size={14} /> AI STORY STUDIO
                  </span>
                  <h2>
                    What should this memory <em>feel like?</em>
                  </h2>
                  <p>
                    Describe the atmosphere. We’ll find the right moments and shape them into a
                    collage.
                  </p>
                  <div className="prompt-box">
                    <textarea
                      value={prompt}
                      onChange={(event) => setPrompt(event.target.value)}
                      placeholder="Dreamy, warm, a little nostalgic..."
                      aria-label="Describe your collage"
                    />
                    <button
                      onClick={generate}
                      className={creating ? "loading" : ""}
                      disabled={creating}
                    >
                      {creating ? "Curating..." : "Create with AI"} <Icon name="arrow" size={17} />
                    </button>
                  </div>
                  <div className="suggestions">
                    {["Sun-faded summer", "Quiet & cinematic", "Joyful chaos"].map((text) => (
                      <button key={text} onClick={() => setPrompt(text)}>
                        {text}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="collage-preview" aria-label="Sample AI collage">
                  <div className="tape tape-one" />
                  <div className="tape tape-two" />
                  <div className="photo-card photo-a">
                    <img src={photos.walk} alt="Friends walking on a beach" />
                  </div>
                  <div className="photo-card photo-b">
                    <img src={photos.beach} alt="Friends sitting together by the sea" />
                  </div>
                  <div className="photo-card photo-c">
                    <img src={photos.path} alt="Friends on a path toward the beach" />
                  </div>
                  <div className="scribble">
                    good days
                    <br />
                    <span>look like this</span>
                  </div>
                  <div className="star">✦</div>
                </div>
              </section>

              <section className="section-block">
                <div className="section-heading">
                  <div>
                    <span className="tiny-label">PICK UP WHERE YOU LEFT OFF</span>
                    <h2>Recent stories</h2>
                  </div>
                  <button className="text-button" onClick={() => navigate("Library")}>
                    View all <Icon name="arrow" size={16} />
                  </button>
                </div>
                <div className="album-grid">
                  {albums.map((album, index) => (
                    <article
                      className="album-card"
                      key={album.title}
                      onClick={() => openAlbum(album.title)}
                    >
                      <div className="album-image" style={{ backgroundColor: album.color }}>
                        <img src={album.image} alt="" />
                        {index === 0 && (
                          <span className="shared-pill">
                            <Icon name="users" size={13} /> SHARED
                          </span>
                        )}
                        <button
                          className="card-menu"
                          aria-label={`Options for ${album.title}`}
                          onClick={(event) => {
                            event.stopPropagation();
                            setMenuAlbum(menuAlbum === album.title ? null : album.title);
                          }}
                        >
                          <Icon name="more" />
                        </button>
                        {menuAlbum === album.title && (
                          <div className="album-menu" onClick={(event) => event.stopPropagation()}>
                            <button onClick={() => openAlbum(album.title)}>
                              <Icon name="edit" size={14} /> Edit story
                            </button>
                            <button
                              onClick={() => showNotice(`Share link copied for “${album.title}”.`)}
                            >
                              <Icon name="share" size={14} /> Copy share link
                            </button>
                            <button onClick={() => showNotice(`“${album.title}” downloaded.`)}>
                              <Icon name="download" size={14} /> Download
                            </button>
                          </div>
                        )}
                        <span className="photo-count">0{index + 3}</span>
                      </div>
                      <div className="album-info">
                        <div>
                          <h3>{album.title}</h3>
                          <p>{album.meta}</p>
                        </div>
                        <button aria-label={`Open ${album.title}`}>
                          <Icon name="arrow" size={18} />
                        </button>
                      </div>
                    </article>
                  ))}
                </div>
              </section>

              <section className="section-block quick-section">
                <div className="section-heading">
                  <div>
                    <span className="tiny-label">MAKE SOMETHING</span>
                    <h2>Start creating</h2>
                  </div>
                </div>
                <div className="quick-grid">
                  {[
                    {
                      icon: "grid",
                      title: "Collage",
                      text: "Layer moments into a mood",
                      tone: "peach",
                    },
                    {
                      icon: "book",
                      title: "Photo journal",
                      text: "Write the story as it happened",
                      tone: "sage",
                    },
                    {
                      icon: "wand",
                      title: "Magic album",
                      text: "Let AI find the thread",
                      tone: "butter",
                    },
                    {
                      icon: "users",
                      title: "Group album",
                      text: "Collect everyone’s angle",
                      tone: "lilac",
                    },
                  ].map((item) => (
                    <button
                      className={`quick-card ${item.tone}`}
                      key={item.title}
                      onClick={() => openCreator(item.title)}
                    >
                      <span className="quick-icon">
                        <Icon name={item.icon as IconName} size={23} />
                      </span>
                      <span>
                        <strong>{item.title}</strong>
                        <small>{item.text}</small>
                      </span>
                      <Icon name="arrow" size={18} />
                    </button>
                  ))}
                </div>
              </section>
            </>
          ) : (
            <WorkspaceView
              active={active}
              onImport={() => setModal({ type: "import", title: "Bring in new memories" })}
              onOpenAlbum={openAlbum}
              onCreate={openCreator}
              liked={liked}
              onLike={(title) =>
                setLiked((current) =>
                  current.includes(title)
                    ? current.filter((item) => item !== title)
                    : [...current, title],
                )
              }
            />
          )}
        </div>
      </main>

      <nav className="bottom-nav" aria-label="Mobile navigation">
        {[
          { label: "Create", icon: "grid", target: "Create" },
          { label: "Shared", icon: "users", target: "Shared" },
          { label: "Add", icon: "camera", target: "Import", center: true },
          { label: "Clean", icon: "sparkle", target: "Library" },
          { label: "Journal", icon: "book", target: "Journal" },
        ].map((item) => (
          <button
            key={item.label}
            className={`${active === item.target ? "active" : ""} ${item.center ? "center-capture" : ""}`}
            onClick={() =>
              item.center
                ? setModal({ type: "import", title: "Bring in new memories" })
                : navigate(item.target)
            }
            aria-label={item.center ? "Add photos" : item.label}
          >
            <span>
              <Icon name={item.icon as IconName} size={item.center ? 22 : 20} />
            </span>
            <small>{item.label}</small>
          </button>
        ))}
      </nav>
      {modal && (
        <Modal
          modal={modal}
          selectedFiles={selectedFiles}
          setSelectedFiles={setSelectedFiles}
          selectedStyle={selectedStyle}
          setSelectedStyle={setSelectedStyle}
          onClose={() => setModal(null)}
          onDone={(message) => {
            setModal(null);
            setSelectedFiles([]);
            showNotice(message);
          }}
        />
      )}
      {notice && (
        <div className="toast">
          <Icon name="sparkle" size={16} />
          {notice}
        </div>
      )}
    </div>
  );
}

function WorkspaceView({
  active,
  onImport,
  onOpenAlbum,
  onCreate,
  liked,
  onLike,
}: {
  active: string;
  onImport: () => void;
  onOpenAlbum: (title: string) => void;
  onCreate: (title: string) => void;
  liked: string[];
  onLike: (title: string) => void;
}) {
  const [filter, setFilter] = useState("All moments");
  const [format, setFormat] = useState("Carousel");
  const [templateStyle, setTemplateStyle] = useState("Editorial");
  const copy: Record<string, { eyebrow: string; title: string; text: string }> = {
    Library: {
      eyebrow: "2,486 MOMENTS",
      title: "Your photo library",
      text: "Every frame, gently sorted by time, place, people, and feeling.",
    },
    Create: {
      eyebrow: "YOUR CREATIVE DESK",
      title: "Make something lasting",
      text: "Begin with a few photos or a feeling. You can change every detail.",
    },
    Shared: {
      eyebrow: "4 SHARED SPACES",
      title: "Better memories, together",
      text: "Collect every angle from the people who were there.",
    },
    Journal: {
      eyebrow: "12 ENTRIES THIS YEAR",
      title: "The stories between photos",
      text: "Small notes, vivid details, and the things you never want to forget.",
    },
  };
  const page = copy[active] ?? copy.Library;

  if (active === "Create") {
    const templates = [
      { name: "Hero + 2", layout: "hero", palette: ["#b4a3bd", "#aabd91", "#d6c8b8"] },
      { name: "Grid", layout: "grid", palette: ["#a9bc90", "#a99abd", "#d4c5b8", "#a9cad2"] },
      { name: "Strip", layout: "strip", palette: ["#d3c4b5", "#8fb8b4", "#c9bdb0"] },
      { name: "Single", layout: "single", palette: ["#a6cad4"] },
      { name: "Postcard", layout: "postcard", palette: ["#d3a995", "#c4c9a9", "#9fb4bf"] },
      { name: "Film stack", layout: "stack", palette: ["#b7a3a0", "#d1c4ad", "#8ca9a4"] },
    ];
    return (
      <section className="workspace-page create-workspace">
        <PageHeading {...page} action="Import photos" onAction={onImport} />
        <div className="format-tabs" aria-label="Canvas format">
          {[
            ["Carousel", "4:5"],
            ["Story", "9:16"],
            ["Square", "1:1"],
            ["Wallpaper", "9:19"],
          ].map(([name, ratio]) => (
            <button
              key={name}
              className={format === name ? "active" : ""}
              onClick={() => setFormat(name)}
            >
              {name} <span>{ratio}</span>
            </button>
          ))}
        </div>
        <div className="template-heading">
          <div>
            <span className="tiny-label">TEMPLATES</span>
            <p>
              {format} · {templateStyle}
            </p>
          </div>
          <button onClick={() => onCreate("Blank canvas")}>
            <Icon name="plus" size={15} /> Blank canvas
          </button>
        </div>
        <div className="template-style-tabs">
          {["Film", "Editorial", "Scrapbook", "Y2K", "Minimal"].map((style) => (
            <button
              key={style}
              className={templateStyle === style ? "active" : ""}
              onClick={() => setTemplateStyle(style)}
            >
              {style}
              {(style === "Scrapbook" || style === "Y2K") && <small>SOON</small>}
            </button>
          ))}
        </div>
        <div className="template-browser">
          {templates.map((template, index) => (
            <button
              className="template-item"
              key={template.name}
              onClick={() => onCreate(`${templateStyle} ${template.name}`)}
            >
              <span className={`template-canvas ${template.layout}`}>
                <span className="template-title">Summer, mostly</span>
                <span className="template-subtitle">Notes from June</span>
                <span className="template-blocks">
                  {template.palette.map((color, colorIndex) => (
                    <i key={color} style={{ backgroundColor: color }} data-index={colorIndex} />
                  ))}
                </span>
                <span className="template-volume">VOL. 0{index + 1}</span>
              </span>
              <span className="template-name">
                <strong>{template.name}</strong>
                <small>{index === 0 ? "Popular" : `${12 + index * 4} layouts`}</small>
              </span>
            </button>
          ))}
        </div>
        <button className="camera-action" onClick={onImport} aria-label="Add photos">
          <Icon name="image" size={20} />
          <span>Add photos</span>
        </button>
      </section>
    );
  }

  if (active === "Journal") {
    return (
      <section className="workspace-page">
        <PageHeading {...page} action="New entry" onAction={() => onCreate("Photo journal")} />
        <div className="journal-layout">
          <article className="journal-feature" onClick={() => onOpenAlbum("Sunday, slowly")}>
            <img src={photos.field} alt="Friends sitting in a grassy field" />
            <div>
              <span>APRIL 28 · SUNDAY</span>
              <h2>
                The kind of afternoon
                <br />
                that asks for nothing
              </h2>
              <p>
                We stayed until the light went soft and the grass left little marks on our palms.
              </p>
              <button>
                Read entry <Icon name="arrow" size={15} />
              </button>
            </div>
          </article>
          <div className="journal-notes">
            {[
              ["MAY 14", "A train window and three quiet hours", "Somewhere south"],
              ["MAY 02", "Things I noticed by the water", "Saltwater days"],
              ["APR 19", "The dinner that lasted until midnight", "At home"],
            ].map(([date, title, place]) => (
              <button key={title} onClick={() => onOpenAlbum(title)}>
                <span>{date}</span>
                <strong>{title}</strong>
                <small>{place}</small>
              </button>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="workspace-page">
      <PageHeading
        {...page}
        action={active === "Shared" ? "New shared album" : "Import photos"}
        onAction={active === "Shared" ? () => onCreate("Group album") : onImport}
      />
      {active === "Library" && (
        <>
          <div className="filter-row">
            {["All moments", "Favorites", "People", "Places", "Recently added"].map((item) => (
              <button
                className={filter === item ? "active" : ""}
                key={item}
                onClick={() => setFilter(item)}
              >
                {item}
              </button>
            ))}
          </div>
          <p className="filter-status">
            Showing {filter.toLowerCase()} <span>· 2,486 photos</span>
          </p>
        </>
      )}
      <div className={`library-masonry ${active === "Shared" ? "shared-grid" : ""}`}>
        {[...albums, ...albums].map((album, index) => {
          const title = index > 2 ? `${album.title} · ${index + 1}` : album.title;
          return (
            <article
              className={`library-photo photo-${index + 1}`}
              key={title}
              onClick={() => onOpenAlbum(album.title)}
            >
              <img src={album.image} alt="" />
              <div className="library-overlay">
                <span>
                  <strong>{album.title}</strong>
                  <small>{active === "Shared" ? `${index + 2} contributors` : album.meta}</small>
                </span>
                <button
                  className={liked.includes(title) ? "liked" : ""}
                  onClick={(event) => {
                    event.stopPropagation();
                    onLike(title);
                  }}
                  aria-label="Favorite"
                >
                  <Icon name="heart" size={17} />
                </button>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}

function PageHeading({
  eyebrow,
  title,
  text,
  action,
  onAction,
}: {
  eyebrow: string;
  title: string;
  text: string;
  action: string;
  onAction: () => void;
}) {
  return (
    <div className="workspace-heading">
      <div>
        <span className="eyebrow">{eyebrow}</span>
        <h1>{title}</h1>
        <p>{text}</p>
      </div>
      <button onClick={onAction}>
        <Icon name="plus" size={17} />
        {action}
      </button>
    </div>
  );
}

function Modal({
  modal,
  selectedFiles,
  setSelectedFiles,
  selectedStyle,
  setSelectedStyle,
  onClose,
  onDone,
}: {
  modal: { type: "import" | "create" | "album"; title: string };
  selectedFiles: string[];
  setSelectedFiles: (files: string[]) => void;
  selectedStyle: string;
  setSelectedStyle: (style: string) => void;
  onClose: () => void;
  onDone: (message: string) => void;
}) {
  const album = albums.find((item) => item.title === modal.title) ?? albums[0];

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={onClose}>
      <section
        className={`modal-card ${modal.type}-modal`}
        role="dialog"
        aria-modal="true"
        aria-label={modal.title}
        onMouseDown={(event) => event.stopPropagation()}
      >
        <button className="modal-close" onClick={onClose} aria-label="Close">
          <Icon name="close" size={19} />
        </button>
        {modal.type === "import" && (
          <>
            <span className="modal-kicker">ADD TO YOUR LIBRARY</span>
            <h2>{modal.title}</h2>
            <p>Choose photos from your device. We’ll organize them by date and suggest moments.</p>
            <label className="drop-zone">
              <input
                type="file"
                accept="image/*,video/*"
                multiple
                onChange={(event) =>
                  setSelectedFiles(Array.from(event.target.files ?? []).map((file) => file.name))
                }
              />
              <span>
                <Icon name="upload" size={25} />
              </span>
              <strong>
                {selectedFiles.length
                  ? `${selectedFiles.length} files selected`
                  : "Drop photos here, or browse"}
              </strong>
              <small>
                {selectedFiles.length
                  ? selectedFiles.slice(0, 3).join(" · ")
                  : "JPG, PNG, HEIC or MP4 · up to 2 GB"}
              </small>
            </label>
            <div className="modal-footer">
              <small>Original quality is always preserved</small>
              <button
                disabled={!selectedFiles.length}
                onClick={() => onDone(`${selectedFiles.length} memories added to your library.`)}
              >
                Import {selectedFiles.length || ""} {selectedFiles.length === 1 ? "item" : "items"}{" "}
                <Icon name="arrow" size={16} />
              </button>
            </div>
          </>
        )}
        {modal.type === "create" && (
          <>
            <span className="modal-kicker">NEW CREATION</span>
            <h2>{modal.title}</h2>
            <p>Choose a visual direction. Your creation will remain completely editable.</p>
            <div className="style-picker">
              {[
                ["Editorial", photos.walk],
                ["Scrapbook", photos.beach],
                ["Cinematic", photos.coast],
              ].map(([style, image]) => (
                <button
                  className={selectedStyle === style ? "selected" : ""}
                  key={style}
                  onClick={() => setSelectedStyle(style)}
                >
                  <img src={image} alt="" />
                  <span>{style}</span>
                  {selectedStyle === style && (
                    <i>
                      <Icon name="check" size={12} />
                    </i>
                  )}
                </button>
              ))}
            </div>
            <label className="creation-name">
              Project name
              <input
                defaultValue={modal.title.length > 30 ? "Untitled summer story" : modal.title}
              />
            </label>
            <div className="modal-footer">
              <button className="secondary-button" onClick={onClose}>
                Not now
              </button>
              <button
                onClick={() => onDone(`${selectedStyle} canvas created — ready for your photos.`)}
              >
                Start creating <Icon name="arrow" size={16} />
              </button>
            </div>
          </>
        )}
        {modal.type === "album" && (
          <>
            <div className="album-modal-hero">
              <img src={album.image} alt="" />
              <span className="modal-kicker">MEMORY STORY · MAY 2025</span>
              <h2>{album.title}</h2>
              <p>{album.meta}</p>
            </div>
            <div className="album-modal-actions">
              <button onClick={() => onDone(`Editing “${album.title}”.`)}>
                <Icon name="edit" size={16} /> Edit story
              </button>
              <button onClick={() => onDone(`Share link copied for “${album.title}”.`)}>
                <Icon name="share" size={16} /> Share
              </button>
              <button onClick={() => onDone(`“${album.title}” downloaded.`)}>
                <Icon name="download" size={16} /> Download
              </button>
            </div>
            <div className="album-modal-grid">
              {[photos.beach, photos.walk, photos.path, photos.coast, photos.field].map(
                (image, index) => (
                  <img key={image} src={image} alt={`Moment ${index + 1}`} />
                ),
              )}
            </div>
          </>
        )}
      </section>
    </div>
  );
}
