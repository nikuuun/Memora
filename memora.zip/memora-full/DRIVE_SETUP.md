# Google Drive sharing: setup

Library → long-press photos → **Share** → upload to a Drive folder → create a link.

## 1. Install the new packages

```bash
npx expo install expo-auth-session expo-web-browser expo-crypto expo-secure-store expo-file-system
```

## 2. Google Cloud console

1. Create a project and enable the **Google Drive API**.
2. Configure the **OAuth consent screen** and add the scope `https://www.googleapis.com/auth/drive.file`.
   While the app is in "Testing", only accounts listed as test users can sign in.
3. Create OAuth client IDs:
   - **iOS**: bundle ID `com.memora.app` (change it everywhere if you use another).
   - **Android**: package `com.memora.app` plus the SHA-1 of your signing key
     (`eas credentials` shows it for EAS builds).

## 3. Put the IDs in the app

Create `.env` in the project root:

```
EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID=1234-abcd.apps.googleusercontent.com
EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID=5678-efgh.apps.googleusercontent.com
```

In `app.json`, replace `YOUR_IOS_CLIENT_ID` in `scheme` with the iOS client ID's first part
(the text before `.apps.googleusercontent.com`). Google sends the user back to the app through
that reversed-ID scheme.

## 4. Rebuild

New native packages and a changed URL scheme need a new development build
(`eas build --profile development --platform ios`). Expo Go will not work for Google sign-in.

## Notes

- Scope is `drive.file`: the app only sees folders and files it created.
- Photos go to `Memora Shared / <album name>` in the user's Drive. The link is only created
  when the user taps **Create share link** and confirms.
- The sign-in token lasts about an hour. After that the user taps Connect again.
- iPhone photos upload as HEIC; people opening the link in a browser may need Drive's preview
  or to download them.
- Not device-tested.
