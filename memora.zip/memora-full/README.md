# Memora

A photo app for iPhone built with Expo / React Native. Swipe through your camera roll to clean it up, and share the photos you pick to a Google Drive folder with a link.

This guide is written for people who have **never used VS Code, a terminal, or Expo before**. Follow the steps in order and you will end up with the app running on a virtual iPhone on your Mac.

---

## Table of contents

- [What the app does](#what-the-app-does)
- [What you need](#what-you-need)
- [Step 1: Install the tools](#step-1-install-the-tools)
- [Step 2: Get the code](#step-2-get-the-code)
- [Step 3: Open the project in VS Code](#step-3-open-the-project-in-vs-code)
- [Step 4: Install the project's packages](#step-4-install-the-projects-packages)
- [Step 5: Set up Google Drive (optional)](#step-5-set-up-google-drive-optional)
- [Step 6: Run the app](#step-6-run-the-app)
- [Using the app](#using-the-app)
- [Troubleshooting](#troubleshooting)
- [Privacy and security](#privacy-and-security)
- [Project structure](#project-structure)
- [Known limitations](#known-limitations)

---

## What the app does

| Tab | What it does | Status |
|---|---|---|
| **Home** | Dashboard with your recent photos | Working |
| **Library** | Grid of your photos. Long-press to select, then **Share** to Google Drive or **Trash** | Working |
| **Clean** | Swipe left to delete, right to keep. Filters for screenshots, videos, Live Photos, selfies and year | Working |
| **Review** (opens from the trash button) | The only place photos are really deleted, in one batch, after you confirm | Working |
| **Camera** | Native camera with filters | Placeholder |
| **Create** | Collages, journals, AI stories | Placeholder |

**Share to Google Drive:** select photos, connect your Google account, upload them to a `Memora Shared` folder in your Drive, then create a link you can send to other people.

**Safety:** nothing is deleted from your phone until you press "Delete" on the Review screen and confirm the iOS popup. Deleted photos stay in "Recently Deleted" for about 30 days.

---

## What you need

- A **Mac** (Apple silicon or Intel). Xcode only runs on macOS.
- About **20 GB of free disk space** (Xcode is large).
- A **Google account** (only for the Google Drive feature).
- An internet connection.

You do **not** need a physical iPhone or a paid Apple Developer account. The app runs in the iOS Simulator (a virtual iPhone on your Mac).

> Windows and Android are not supported or tested in this guide.

---

## Step 1: Install the tools

You only do this once.

### 1.1 VS Code (the editor)

1. Go to <https://code.visualstudio.com> and click **Download for Mac**.
2. Open the downloaded ZIP. Drag **Visual Studio Code** into your **Applications** folder.
3. Open it from Launchpad, or press `⌘ + Space`, type `Visual Studio Code` and press `Enter`.

### 1.2 Node.js (runs the project's tools)

1. Go to <https://nodejs.org> and click the **LTS** download button (version 20.19 or newer).
2. Open the downloaded `.pkg` file and keep clicking **Continue** until it is installed.

### 1.3 Xcode (provides the virtual iPhone)

1. Open the **App Store**, search for **Xcode**, and click **Get**. It is a large download.
2. Open Xcode once. Accept the license agreement and click **Install** if it asks for extra components. Enter your Mac password when asked.
3. In the top menu choose **Xcode → Settings → Components** (in newer versions it may be called **Platforms**) and make sure an **iOS** simulator is installed. If not, click **Get** next to it.
4. You can close Xcode afterwards.

### 1.4 Git (only if you want to clone from GitHub)

Open the **Terminal** app (press `⌘ + Space`, type `Terminal`, `Enter`) and run:

```bash
git --version
```

If a popup asks to install the "command line developer tools", click **Install**.

### 1.5 Check everything

In Terminal, run these one at a time. Each should print a version number:

```bash
node -v
npm -v
xcodebuild -version
```

If `node` or `npm` says `command not found`, quit Terminal, open it again, and retry. If it still fails, re-install Node.js.

---

## Step 2: Get the code

Pick **one** of the two options.

### Option A: Download a ZIP (easiest)

1. On the GitHub page of this project, click the green **Code** button, then **Download ZIP**.
2. Double-click the ZIP in your Downloads folder to unzip it. You get a folder, for example `memora-main`.
3. Move that folder somewhere easy to find, such as your Desktop or Documents.

### Option B: Clone with Git

In Terminal:

```bash
cd ~/Documents
git clone <PASTE-THE-REPOSITORY-URL-HERE>
```

(Copy the URL from the green **Code** button on GitHub.)

---

## Step 3: Open the project in VS Code

1. Open VS Code.
2. In the top menu click **File → Open Folder…**
3. Choose the **project folder itself** (the one that contains `package.json`) and click **Open**. Do not go inside the folder.
4. If VS Code asks *"Do you trust the authors of the files in this folder?"*, click **Yes, I trust the authors**.
5. On the left you should now see files like `app`, `src`, `package.json`. If the file list is hidden, click the icon of **two overlapping pages** at the top of the left-hand bar (this is the Explorer).

### Open the built-in terminal

In the top menu click **Terminal → New Terminal**. (Shortcut: `Ctrl + `` ` ``, the key left of the number 1.)

A panel opens at the bottom of VS Code. This is where you will type the commands below. To run a command: paste it, then press `Enter`.

> The terminal is already "inside" your project folder. You can check with `pwd`, which should end with the project's folder name.

---

## Step 4: Install the project's packages

In the VS Code terminal, run:

```bash
npm install
```

This takes 1 to 3 minutes. Warnings in yellow are normal. You can ignore the message about "vulnerabilities". **Do not run `npm audit fix --force`**, it can break the project.

Then run:

```bash
npx expo install --fix
```

If it asks `Ok to proceed? (y)`, type `y` and press `Enter`.

Optional check that the code has no type errors (it should print nothing):

```bash
npx tsc --noEmit
```

---

## Step 5: Set up Google Drive (optional)

Skip this whole step if you only want to try the cleaning features. Without it, the **Share** screen shows a *"Google Drive is not set up yet"* message when you tap **Connect Google Drive**, and everything else works.

Google needs to know which app is asking for access to a Drive. So you register the app once for free. Menu names may differ slightly, so if something looks different, look for the closest match.

> **Working in a team?** Either (a) every person does these steps in their own Google Cloud project (best for privacy), or (b) one person does it and adds each teammate's Google email under **Test users** (Step 5.4), then shares the **Client ID** privately. The Client ID is not a password, but do not post tokens or passwords anywhere.

### 5.1 Create a project

1. Go to <https://console.cloud.google.com> and sign in with the Google account you want to use.
2. Click the **project picker** at the top (next to the Google Cloud logo) and click **New Project**.
3. Name it `Memora` and click **Create**. Then select the new project in the picker.

### 5.2 Turn on the Drive API

1. Open the **☰ menu → APIs & Services → Library**.
2. Search for `Google Drive API`, open it, and click **Enable**.

### 5.3 Create the consent screen and add the Drive permission

1. Open **☰ menu → APIs & Services → OAuth consent screen** (it may be named **Google Auth Platform**) and click **Get started**.
2. App name: `Memora`. Choose your email as support email. Click **Next**.
3. Audience: choose **External**. Click **Next**.
4. Contact email: your email. Click **Next**, agree to the policy, then **Continue → Create**.
5. In the left menu open **Data Access → Add or remove scopes**. Search for `drive.file`, tick `.../auth/drive.file`, click **Update**, then **Save**.

> `drive.file` lets the app see **only the files and folders it created itself**. It cannot read the rest of your Drive.

### 5.4 Add yourself as a test user (important)

1. Left menu → **Audience**.
2. Under **Test users** click **+ Add users**, enter every Google email that will sign in to the app, and click **Save**.

If you skip this, sign-in fails with *"Access blocked"*. Leave the publishing status as **Testing**. Do **not** click **Publish app**.

### 5.5 Create the iOS client ID

1. Left menu → **Clients → Create client**.
2. Application type: **iOS**. Name: `Memora iOS`.
3. Bundle ID: exactly `com.memora.app` (all lowercase).
4. Click **Create** and copy the **Client ID**. It looks like `1234567890-abcdefg.apps.googleusercontent.com`.

### 5.6 Put the Client ID in the project

1. In VS Code, find the file `.env.example` in the file list.
2. Right-click the empty area of the file list → **New File** → name it `.env` (with the dot at the start).
3. Paste this into `.env`, replacing the value with your own Client ID, and save with `⌘ + S`:

```
EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID=1234567890-abcdefg.apps.googleusercontent.com
```

No quotes, no spaces. The `.env` file must sit next to `package.json` (not inside a subfolder). It is listed in `.gitignore`, so it is never uploaded to GitHub.

You do **not** need to edit `app.json`. The file `app.config.js` builds the Google sign-in URL from your `.env` automatically.

---

## Step 6: Run the app

There are two ways. Start with A to see the screens quickly. Use B for everything, including Google Drive.

### A. Quick preview with Expo Go (no Google Drive)

1. In the terminal:

```bash
npx expo start --go --ios
```

2. The iOS Simulator opens by itself and Expo Go installs inside it. The first start can take 1 to 3 minutes.
3. When the app asks for photo access, choose **Allow Full Access**.

Google sign-in does **not** work in Expo Go. Press `Ctrl + C` in the terminal to stop.

### B. Real build (needed for Google Drive)

1. Stop any running server with `Ctrl + C`.
2. Run:

```bash
npx expo run:ios
```

3. **The first build takes 5 to 15 minutes.** You will see hundreds of lines such as `Compiling react-native-reanimated ...`. That is normal. Do not close the terminal or let the Mac sleep (plug in the charger).
4. If it says *"CocoaPods CLI not found"* it tries to install it for you. If that fails, see [Troubleshooting](#troubleshooting).
5. When it finishes, the Simulator shows a **Memora** icon on the home screen and the app opens automatically.

Next time, just start the app with:

```bash
npx expo start --dev-client
```

then open **Memora** in the Simulator. You only need to rebuild (`npx expo run:ios`) after adding a package that contains native code or changing `app.json` / `app.config.js` / `.env`.

---

## Using the app

### Add photos to the Simulator

The virtual iPhone has only a few sample photos. To add your own, drag image files from Finder **onto the Simulator window**. They land in the Photos app. Open Memora again and allow **Full Access** if it asks.

### Clean up photos

1. Open the **Clean** tab.
2. Swipe a photo **left to delete** or **right to keep**, or use the buttons below the card. The arrow button undoes the last decision.
3. Use the chips at the top to filter (Screenshots, Videos, a year, ...). The **layers** button moves everything matching the filter to the trash.
4. Nothing is really deleted yet. Photos only go into a trash queue.
5. Tap the **trash button** (top right) to open **Review**, check the photos (tap a photo to rescue it), and press **Delete N items**. iOS shows one confirmation popup.

### Share photos through Google Drive

1. Open the **Library** tab and **long-press** a photo. Tap more photos to add them.
2. Tap **Share** (top right).
3. Enter an album name and tap **Connect Google Drive**.
4. Sign in with a Google account you added as a **test user**. If Google says *"Google hasn't verified this app"*, tap **Advanced → Go to Memora (unsafe)**. This is expected for your own app in testing mode.
5. Tap **Upload to Drive**. Keep the app open until it finishes.
6. Tap **Create share link**, confirm the warning (*anyone with the link can view*), then send the link with the iOS share sheet.
7. To stop sharing later, open the folder in Google Drive and remove the link access.

Use **Disconnect Google account** on the share screen to sign out.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `command not found: npm` or `node` | Install Node.js (Step 1.2), then quit and reopen the terminal. |
| `npx expo start` seems stuck on "Starting Metro Bundler" | Wait up to 3 minutes. If still stuck, press `Ctrl + C` and run `npx expo start --go --ios --clear`. |
| Crash with `osascript ... System Events` when starting with `--ios` | macOS blocked the terminal from controlling Simulator. Run `tccutil reset AppleEvents`, start again and click **Allow** on the popup. Or open **System Settings → Privacy & Security → Automation** and enable **System Events** for **Visual Studio Code**. Or start without `--ios`, open the Simulator yourself, and open the app there. |
| Simulator opens but the app does not | Click the terminal and press `i`. Or open **Expo Go** (Quick preview) or **Memora** (real build) in the Simulator by hand. |
| `CocoaPods CLI not found` / `Failed to install CocoaPods CLI with gem` | Install Homebrew from <https://brew.sh> (follow the "Next steps" it prints), then run `brew install cocoapods`, check with `pod --version`, and run `npx expo run:ios` again. |
| Red screen: `Cannot find native module 'ExpoFontLoader'` | A native package is missing from the build. Run `npx expo install expo-font expo-constants expo-linking`, then `npx expo prebuild --clean`, then `npx expo run:ios`. |
| Red screen: `No suitable URL request handler found for ph://...` | An `Image` from `react-native` was used for a photo. Use `Image` from `expo-image` instead. |
| Library or Clean is empty | Add photos to the Simulator (drag files onto its window) and allow **Full Access** to photos. |
| Share screen says *"Google Drive is not set up yet"* | `.env` is missing, in the wrong folder, or has a typo. Fix it, then rebuild with `npx expo run:ios`. Google sign-in also does not work in Expo Go. |
| Google says *"Access blocked"* or *"Error 403: access_denied"* | The Google email is not in **Test users** (Step 5.4). Add it and try again. |
| Google says the app is not verified | Tap **Advanced → Go to Memora (unsafe)**. |
| *"Your Google session expired"* | Sign-in lasts about 1 hour. Tap **Connect Google Drive** again. |
| Google sign-in window shows an `invalid_request` or redirect error | The Bundle ID in Google Cloud must be exactly `com.memora.app`, and the Client ID in `.env` must be the **iOS** client. Check both, then rebuild. |
| Build fails after changing packages | Run `npx expo prebuild --clean` and then `npx expo run:ios`. As a last resort delete the `node_modules` and `ios` folders and start again from Step 4. |
| Warning `Linking found multiple possible URI schemes` | Harmless. Ignore it. |
| Yellow warning `Expo Go can no longer provide full access to the media library` | This message is about Android. Ignore it on iPhone. |
| Changed `.env` but nothing happens | Stop the server, run `npx expo run:ios` again (the value is built into the app), or at least `npx expo start --dev-client --clear`. |

Still stuck? Copy the **red error text** (not a screenshot of the whole screen) from the terminal and include it when you ask for help.

---

## Privacy and security

- Photos are only read on your device. **Nothing is uploaded** unless you tap **Upload to Drive**.
- Uploads go **directly from your phone to Google**. There is no Memora server.
- The app uses the narrow Google permission `drive.file`: it can only access files it created itself.
- The sign-in token is kept in the iOS secure storage (Keychain) and expires after about an hour. **Disconnect Google account** deletes it and asks Google to revoke it.
- A share link is created **only after you confirm**. Anyone with the link can view the folder. Remove the link access in Google Drive to stop sharing.
- The Google Client ID is a public identifier, not a password, but your `.env` is still excluded from Git. **Never commit or post** passwords, access tokens or verification codes.
- Photos are deleted only on the **Review** screen after an iOS confirmation. Deleted items stay in "Recently Deleted" for about 30 days.
- Test with a few junk photos before trusting the app with irreplaceable ones. The app has been tested in the iOS Simulator, not on a wide range of real devices.

---

## Project structure

```
app/                         screens (Expo Router: one file = one screen)
  _layout.tsx                root navigation (tabs + Review and Share modals)
  review.tsx                 review the trash, then ONE batch delete
  share.tsx                  upload selected photos to Google Drive + share link
  (tabs)/
    _layout.tsx              bottom tab bar
    index.tsx                Home
    library.tsx              photo grid, long-press to select, Share / Trash
    clean.tsx                swipe deck, filters
    camera.tsx               placeholder
    create.tsx               placeholder
src/
  theme.ts                   colors and spacing
  components/                SwipeCard, PhotoTile, Chip
  photos/                    permission gate, photo queries, paged loading
  trash/store.ts             trash queue (saved on the device, with undo)
  drive/
    config.ts                Google settings (reads .env)
    auth.ts                  Google sign-in and secure token storage
    api.ts                   Drive API calls (folders, upload, share link)
    uploader.ts              uploads photos a few at a time, retry on failure
    shareSelection.ts        photos picked in Library for sharing
app.json                     app name, permissions, Bundle ID
app.config.js                adds the Google sign-in URL from .env
.env.example                 template for your private .env
```

The `ios/` folder is generated automatically by `npx expo run:ios` and is not stored in Git.

---

## Known limitations

- Tested only on the **iOS Simulator** (iPhone 17 Pro, Expo SDK 54). Android, Windows and physical devices are untested.
- Camera and Create tabs are design placeholders.
- Google sign-in lasts about 1 hour and is not refreshed automatically. Tap **Connect** again.
- iPhone photos upload as HEIC. Browsers may not preview them, so recipients may need to download them.
- Keep the app open while uploading. There is no background upload yet.
- Smart-album filters (Screenshots, Live Photos, Selfies) match English album names.
- There is no full-screen photo viewer yet.
- The app is in Google's **Testing** mode, so only listed test users can sign in (limit 100).
