import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Linking,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { PhotoTile } from '../src/components/PhotoTile';
import { DriveAuthError, shareFolder } from '../src/drive/api';
import { useDriveAuth } from '../src/drive/auth';
import { useShareSelection } from '../src/drive/shareSelection';
import { uploadAlbum } from '../src/drive/uploader';
import type { QueuedPhoto } from '../src/trash/store';
import { colors, radius, space } from '../src/theme';

type Phase = 'idle' | 'uploading' | 'done';

/** Upload the photos picked in Library to a Google Drive folder, then share a link. */
export default function ShareScreen() {
  const items = useShareSelection((s) => s.items);
  const { token, signIn, signOut, loading, configured, ready } = useDriveAuth();

  const [name, setName] = useState(`Memora ${new Date().toLocaleDateString()}`);
  const [phase, setPhase] = useState<Phase>('idle');
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const [folderId, setFolderId] = useState<string>();
  const [failed, setFailed] = useState<QueuedPhoto[]>([]);
  const [link, setLink] = useState<string>();
  const [error, setError] = useState<string>();
  const [linking, setLinking] = useState(false);
  const abort = useRef<AbortController | null>(null);

  useEffect(() => () => abort.current?.abort(), []);

  const upload = async (photos: QueuedPhoto[], existingFolder?: string) => {
    if (!token) return;
    const controller = new AbortController();
    abort.current = controller;
    setError(undefined);
    setPhase('uploading');
    try {
      const res = await uploadAlbum({
        token,
        albumName: name.trim() || 'Memora album',
        photos,
        folderId: existingFolder,
        signal: controller.signal,
        onProgress: (done, total) => setProgress({ done, total }),
      });
      setFolderId(res.folderId);
      setFailed(res.failed);
      setPhase(res.cancelled ? 'idle' : 'done');
    } catch (e) {
      if (e instanceof DriveAuthError) {
        await signOut();
        setError('Your Google session expired. Connect again to continue.');
      } else {
        setError(e instanceof Error ? e.message : String(e));
      }
      setPhase('idle');
    }
  };

  const makeLink = () => {
    if (!token || !folderId) return;
    Alert.alert(
      'Create a share link?',
      'Anyone who has the link will be able to view these photos. You can stop sharing from Google Drive at any time.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Create link',
          onPress: async () => {
            setLinking(true);
            try {
              const url = await shareFolder(token, folderId);
              setLink(url);
              await Share.share({ message: url });
            } catch (e) {
              if (e instanceof DriveAuthError) {
                await signOut();
                setError('Your Google session expired. Connect again to create the link.');
              } else {
                Alert.alert('Could not create the link', e instanceof Error ? e.message : String(e));
              }
            } finally {
              setLinking(false);
            }
          },
        },
      ],
    );
  };

  const showSetupNeeded = () =>
    Alert.alert(
      'Google Drive is not set up yet',
      'Add your Google client IDs (see DRIVE_SETUP.md) and rebuild the app, then this button will sign you in.',
    );

  if (items.length === 0 && phase === 'idle') {
    return (
      <SafeAreaView style={s.safe} edges={['bottom']}>
        <View style={s.center}>
          <Text style={s.title}>Nothing selected</Text>
          <Text style={s.body}>Long-press photos in Library, then tap Share.</Text>
          <Pressable style={s.primary} onPress={() => router.back()}>
            <Text style={s.primaryText}>Back to Library</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={s.safe} edges={['bottom']}>
      <ScrollView contentContainerStyle={s.content}>
        {phase !== 'done' && (
          <>
            <Text style={s.title}>
              Share {items.length} {items.length === 1 ? 'photo' : 'photos'}
            </Text>
            <Text style={s.body}>
              The photos are copied to a folder in your Google Drive. Your originals stay on this phone.
            </Text>

            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.strip}>
              {items.slice(0, 12).map((p) => (
                <PhotoTile key={p.id} id={p.id} uri={p.uri} size={64} isVideo={p.mediaType === 'video'} />
              ))}
            </ScrollView>

            <Text style={s.label}>Album name</Text>
            <TextInput
              value={name}
              onChangeText={setName}
              editable={phase === 'idle'}
              style={s.input}
              placeholder="Album name"
              placeholderTextColor={colors.muted}
              maxLength={80}
            />
          </>
        )}

        {error && <Text style={s.error}>{error}</Text>}

        {phase === 'idle' &&
          (loading ? (
            <ActivityIndicator style={{ marginTop: space.xl }} />
          ) : !token ? (
            <>
              <Pressable
                style={[s.primary, configured && !ready && s.disabled]}
                onPress={configured ? signIn : showSetupNeeded}
                disabled={configured && !ready}
              >
                <Ionicons name="logo-google" size={18} color={colors.bg} />
                <Text style={s.primaryText}>Connect Google Drive</Text>
              </Pressable>
              {!configured && (
                <Text style={s.hint}>
                  Google client IDs are not added yet, so connecting will not work until they are (see DRIVE_SETUP.md).
                </Text>
              )}
            </>
          ) : (
            <>
              <Pressable style={s.primary} onPress={() => upload(items)}>
                <Ionicons name="cloud-upload-outline" size={20} color={colors.bg} />
                <Text style={s.primaryText}>Upload to Drive</Text>
              </Pressable>
              <Pressable onPress={signOut} style={s.secondary}>
                <Text style={s.secondaryText}>Disconnect Google account</Text>
              </Pressable>
            </>
          ))}

        {phase === 'uploading' && (
          <View style={s.progressBox}>
            <ActivityIndicator />
            <Text style={s.body}>
              Uploading {progress.done} of {progress.total}…
            </Text>
            <Text style={s.hint}>Keep Memora open until this finishes.</Text>
            <Pressable onPress={() => abort.current?.abort()} style={s.secondary}>
              <Text style={s.secondaryText}>Stop</Text>
            </Pressable>
          </View>
        )}

        {phase === 'done' && (
          <View style={s.doneBox}>
            <Ionicons name="checkmark-circle" size={48} color={colors.keep} />
            <Text style={s.title}>
              {progress.total - failed.length} of {progress.total} uploaded
            </Text>
            {failed.length > 0 && (
              <>
                <Text style={s.error}>
                  {failed.length} could not be uploaded (offline, or still downloading from iCloud).
                </Text>
                <Pressable style={s.secondary} onPress={() => upload(failed, folderId)}>
                  <Text style={s.secondaryText}>Retry {failed.length} failed</Text>
                </Pressable>
              </>
            )}
            <Pressable style={[s.primary, linking && s.disabled]} onPress={makeLink} disabled={linking}>
              {linking ? (
                <ActivityIndicator color={colors.bg} />
              ) : (
                <>
                  <Ionicons name="link-outline" size={20} color={colors.bg} />
                  <Text style={s.primaryText}>{link ? 'Share link again' : 'Create share link'}</Text>
                </>
              )}
            </Pressable>
            {link && (
              <Pressable style={s.secondary} onPress={() => Linking.openURL(link)}>
                <Text style={s.secondaryText}>Open in Google Drive</Text>
              </Pressable>
            )}
            <Pressable style={s.secondary} onPress={() => router.back()}>
              <Text style={s.secondaryText}>Done</Text>
            </Pressable>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { padding: space.xl, gap: space.md },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: space.xl, gap: space.md },
  title: { fontFamily: 'Georgia', fontSize: 26, color: colors.text, textAlign: 'center' },
  body: { fontSize: 14, lineHeight: 21, color: colors.muted, textAlign: 'center' },
  hint: { fontSize: 12, color: colors.muted, textAlign: 'center' },
  strip: { flexGrow: 0, marginVertical: space.sm },
  label: { fontSize: 12, fontWeight: '700', letterSpacing: 1, color: colors.muted, marginTop: space.sm },
  input: {
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: radius.sm,
    backgroundColor: colors.surface,
    paddingHorizontal: space.md,
    paddingVertical: 12,
    fontSize: 16,
    color: colors.text,
  },
  primary: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: space.sm,
    backgroundColor: colors.ink,
    borderRadius: radius.md,
    paddingVertical: 16,
    paddingHorizontal: space.xl,
    marginTop: space.md,
  },
  primaryText: { color: colors.bg, fontSize: 16, fontWeight: '600' },
  disabled: { opacity: 0.5 },
  secondary: { alignItems: 'center', paddingVertical: space.sm },
  secondaryText: { color: colors.text, fontSize: 15 },
  error: { color: colors.danger, fontSize: 14, lineHeight: 20, textAlign: 'center' },
  progressBox: { alignItems: 'center', gap: space.md, marginTop: space.xl },
  doneBox: { alignItems: 'center', gap: space.sm, marginTop: space.xl },
});
