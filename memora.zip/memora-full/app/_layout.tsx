import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <StatusBar style="dark" />
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen
          name="review"
          options={{ presentation: 'modal', headerShown: true, title: 'Review trash' }}
        />
        <Stack.Screen
          name="share"
          options={{ presentation: 'modal', headerShown: true, title: 'Share to Google Drive' }}
        />
      </Stack>
    </GestureHandlerRootView>
  );
}
