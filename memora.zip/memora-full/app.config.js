/**
 * Extends app.json with values that come from your private .env file,
 * so personal Google IDs never have to be committed to GitHub.
 *
 * EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID=1234-abcd.apps.googleusercontent.com
 *   -> adds the URL scheme com.googleusercontent.apps.1234-abcd,
 *      which Google uses to send the user back to the app after sign-in.
 */
module.exports = ({ config }) => {
  const clientId = process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID ?? '';
  const suffix = '.apps.googleusercontent.com';
  const reversed = clientId.endsWith(suffix)
    ? `com.googleusercontent.apps.${clientId.slice(0, -suffix.length)}`
    : null;

  const base = Array.isArray(config.scheme) ? config.scheme : [config.scheme];
  return { ...config, scheme: [...base, ...(reversed ? [reversed] : [])] };
};
