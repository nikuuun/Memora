import * as MediaLibrary from 'expo-media-library';

import type { QueuedPhoto } from '../trash/store';
import { createFolder, DriveAuthError, findOrCreateFolder, guessMime, uploadFile } from './api';
import { ROOT_FOLDER_NAME, UPLOAD_CONCURRENCY } from './config';

export type UploadResult = {
  folderId: string;
  /** Photos that did not upload; pass them back in with `folderId` to retry. */
  failed: QueuedPhoto[];
  cancelled: boolean;
};

type Options = {
  token: string;
  albumName: string;
  photos: QueuedPhoto[];
  /** Reuse an existing album folder (for "retry failed"). */
  folderId?: string;
  signal: AbortSignal;
  onProgress: (done: number, total: number) => void;
};

async function uploadOne(token: string, folderId: string, photo: QueuedPhoto) {
  // iCloud photos are downloaded first; this is why it can take a moment.
  const info = await MediaLibrary.getAssetInfoAsync(photo.id, { shouldDownloadFromNetwork: true });
  if (!info) throw new Error('Photo no longer exists');
  const uri = info.localUri ?? info.uri;
  await uploadFile(token, folderId, uri, info.filename, guessMime(info.filename, photo.mediaType));
}

/** Uploads photos into a new Drive album folder, a few at a time. */
export async function uploadAlbum(opts: Options): Promise<UploadResult> {
  const { token, albumName, photos, signal, onProgress } = opts;

  const folderId =
    opts.folderId ?? (await createFolder(token, albumName, await findOrCreateFolder(token, ROOT_FOLDER_NAME)));

  const failed: QueuedPhoto[] = [];
  let next = 0;
  let done = 0;
  let stop = false;
  onProgress(0, photos.length);

  const worker = async () => {
    while (!signal.aborted && !stop) {
      const i = next++;
      if (i >= photos.length) return;
      try {
        await uploadOne(token, folderId, photos[i]);
      } catch (e) {
        if (e instanceof DriveAuthError) {
          stop = true;
          throw e;
        }
        failed.push(photos[i]);
      }
      done += 1;
      onProgress(done, photos.length);
    }
  };

  await Promise.all(Array.from({ length: Math.min(UPLOAD_CONCURRENCY, photos.length) }, worker));
  return { folderId, failed, cancelled: signal.aborted };
}
