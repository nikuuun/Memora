/**
 * Google Drive settings. Client IDs come from your Google Cloud console
 * (see DRIVE_SETUP.md) and are read from EXPO_PUBLIC_* env vars at build time.
 */
export const GOOGLE = {
  iosClientId: process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID,
  androidClientId: process.env.EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID,
};

/**
 * drive.file = the app can only see files and folders it created itself.
 * It cannot read the rest of the user's Drive.
 */
export const DRIVE_SCOPES = ['https://www.googleapis.com/auth/drive.file'];

/** Top-level Drive folder; each shared album becomes a sub-folder inside it. */
export const ROOT_FOLDER_NAME = 'Memora Shared';

/** How many photos upload at the same time. */
export const UPLOAD_CONCURRENCY = 3;
