import * as FileSystem from 'expo-file-system/legacy';

const API = 'https://www.googleapis.com/drive/v3';
const UPLOAD = 'https://www.googleapis.com/upload/drive/v3';

/** Thrown when Google rejects the token (expired or revoked). */
export class DriveAuthError extends Error {}

async function call(token: string, url: string, init?: RequestInit) {
  const res = await fetch(url, {
    ...init,
    headers: { Authorization: `Bearer ${token}`, ...(init?.headers as Record<string, string> | undefined) },
  });
  if (res.status === 401) throw new DriveAuthError('Google session expired');
  if (!res.ok) throw new Error(`Drive ${res.status}: ${await res.text()}`);
  return res;
}

const jsonHeaders = { 'Content-Type': 'application/json; charset=UTF-8' };
const escapeQuery = (s: string) => s.replace(/\\/g, '\\\\').replace(/'/g, "\\'");

/** Finds a folder this app created, or makes it. */
export async function findOrCreateFolder(token: string, name: string): Promise<string> {
  const q = `name='${escapeQuery(name)}' and mimeType='application/vnd.google-apps.folder' and trashed=false`;
  const res = await call(token, `${API}/files?q=${encodeURIComponent(q)}&fields=files(id)&pageSize=1`);
  const data = (await res.json()) as { files?: { id: string }[] };
  if (data.files?.[0]) return data.files[0].id;
  return createFolder(token, name);
}

export async function createFolder(token: string, name: string, parentId?: string): Promise<string> {
  const res = await call(token, `${API}/files?fields=id`, {
    method: 'POST',
    headers: jsonHeaders,
    body: JSON.stringify({
      name,
      mimeType: 'application/vnd.google-apps.folder',
      ...(parentId ? { parents: [parentId] } : {}),
    }),
  });
  return ((await res.json()) as { id: string }).id;
}

/**
 * Resumable upload straight from a file on disk, so big photos and videos are
 * streamed instead of loaded into memory.
 */
export async function uploadFile(token: string, folderId: string, localUri: string, name: string, mime: string) {
  const init = await call(token, `${UPLOAD}/files?uploadType=resumable&fields=id`, {
    method: 'POST',
    headers: { ...jsonHeaders, 'X-Upload-Content-Type': mime },
    body: JSON.stringify({ name, parents: [folderId] }),
  });
  const session = init.headers.get('Location');
  if (!session) throw new Error('Drive did not return an upload URL');

  const res = await FileSystem.uploadAsync(session, localUri, {
    httpMethod: 'PUT',
    uploadType: FileSystem.FileSystemUploadType.BINARY_CONTENT,
    headers: { 'Content-Type': mime },
  });
  if (res.status === 401) throw new DriveAuthError('Google session expired');
  if (res.status !== 200 && res.status !== 201) throw new Error(`Upload failed (${res.status})`);
}

/** "Anyone with the link can view" on a folder, then returns the link. */
export async function shareFolder(token: string, folderId: string): Promise<string> {
  await call(token, `${API}/files/${folderId}/permissions`, {
    method: 'POST',
    headers: jsonHeaders,
    body: JSON.stringify({ role: 'reader', type: 'anyone' }),
  });
  const res = await call(token, `${API}/files/${folderId}?fields=webViewLink`);
  const link = ((await res.json()) as { webViewLink?: string }).webViewLink;
  if (!link) throw new Error('Drive did not return a link');
  return link;
}

const MIME_BY_EXT: Record<string, string> = {
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  png: 'image/png',
  heic: 'image/heic',
  heif: 'image/heif',
  gif: 'image/gif',
  webp: 'image/webp',
  mp4: 'video/mp4',
  mov: 'video/quicktime',
  m4v: 'video/x-m4v',
  '3gp': 'video/3gpp',
};

export function guessMime(filename: string | undefined, mediaType: string): string {
  const ext = filename?.split('.').pop()?.toLowerCase();
  if (ext && MIME_BY_EXT[ext]) return MIME_BY_EXT[ext];
  return mediaType === 'video' ? 'video/mp4' : 'image/jpeg';
}
