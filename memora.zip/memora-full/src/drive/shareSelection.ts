import { create } from 'zustand';

import type { QueuedPhoto } from '../trash/store';

/** Photos the user picked in Library to share. Lives in memory only. */
export const useShareSelection = create<{
  items: QueuedPhoto[];
  setItems: (items: QueuedPhoto[]) => void;
}>((set) => ({
  items: [],
  setItems: (items) => set({ items }),
}));
