import * as Google from 'expo-auth-session/providers/google';
import * as SecureStore from 'expo-secure-store';
import * as WebBrowser from 'expo-web-browser';
import { useCallback, useEffect, useState } from 'react';
import { Platform } from 'react-native';

import { DRIVE_SCOPES, GOOGLE } from './config';

WebBrowser.maybeCompleteAuthSession();

const KEY = 'memora-drive-token';
type Saved = { accessToken: string; expiresAt: number };

/**
 * Google sign-in for Drive. The access token lives in the device's secure
 * storage and lasts about an hour; after that the user taps "Connect" again.
 */
export function useDriveAuth() {
  const configured =
    Platform.OS === 'ios' ? !!GOOGLE.iosClientId : Platform.OS === 'android' ? !!GOOGLE.androidClientId : false;

  const [request, response, promptAsync] = Google.useAuthRequest({
    // useAuthRequest throws if an ID is missing, so pass a placeholder and
    // report `configured: false` instead.
    iosClientId: GOOGLE.iosClientId ?? 'missing',
    androidClientId: GOOGLE.androidClientId ?? 'missing',
    scopes: DRIVE_SCOPES,
  });

  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  // Restore a saved token if it is still valid.
  useEffect(() => {
    (async () => {
      try {
        const raw = await SecureStore.getItemAsync(KEY);
        if (raw) {
          const saved = JSON.parse(raw) as Saved;
          if (saved.expiresAt - Date.now() > 60_000) setToken(saved.accessToken);
          else await SecureStore.deleteItemAsync(KEY);
        }
      } catch {
        // unreadable token: treat as signed out
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // Save the token after a successful sign-in.
  useEffect(() => {
    if (response?.type !== 'success') return;
    const auth = response.authentication;
    if (!auth?.accessToken) return;
    const expiresAt = Date.now() + (auth.expiresIn ?? 3600) * 1000;
    setToken(auth.accessToken);
    SecureStore.setItemAsync(KEY, JSON.stringify({ accessToken: auth.accessToken, expiresAt } satisfies Saved)).catch(
      () => {},
    );
  }, [response]);

  const signIn = useCallback(() => {
    if (request) promptAsync();
  }, [request, promptAsync]);

  const signOut = useCallback(async () => {
    const old = token;
    setToken(null);
    await SecureStore.deleteItemAsync(KEY).catch(() => {});
    if (old) {
      // Best effort: tell Google to revoke the token.
      fetch(`https://oauth2.googleapis.com/revoke?token=${encodeURIComponent(old)}`, { method: 'POST' }).catch(
        () => {},
      );
    }
  }, [token]);

  return { token, signIn, signOut, loading, configured, ready: !!request };
}
